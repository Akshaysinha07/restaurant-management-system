<?php require __DIR__ . '/../config.php'; require_login();
$cart = $_SESSION['cart'] ?? [];
if (!$cart) { header("Location: /restaurant_dbms/cart.php"); exit; }

$pdo->beginTransaction();
try {
    $ids = array_keys($cart);
    $in = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("SELECT id, price FROM menu_items WHERE id IN ($in) AND is_available = 1");
    $stmt->execute($ids);
    $items = $stmt->fetchAll();
    if (count($items) !== count($ids)) {
        throw new Exception("Some items unavailable.");
    }
    $total = 0;
    $price_map = [];
    foreach ($items as $it) { $price_map[$it['id']] = (float)$it['price']; }
    foreach ($cart as $id => $ci) {
        $total += $ci['qty'] * $price_map[$id];
    }
    $stmt = $pdo->prepare("INSERT INTO orders (user_id, total) VALUES (?, ?)");
    $stmt->execute([current_user()['id'], $total]);
    $order_id = $pdo->lastInsertId();

    $stmtItem = $pdo->prepare("INSERT INTO order_items (order_id, menu_item_id, quantity, unit_price) VALUES (?, ?, ?, ?)");
    foreach ($cart as $id => $ci) {
        $stmtItem->execute([$order_id, $id, $ci['qty'], $price_map[$id]]);
    }
    $pdo->commit();
    unset($_SESSION['cart']);
    header("Location: /restaurant_dbms/customer/my_orders.php?placed=1");
    exit;
} catch (Exception $e) {
    $pdo->rollBack();
    die("Failed to place order: " . $e->getMessage());
}
