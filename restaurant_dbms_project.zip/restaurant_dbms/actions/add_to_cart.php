<?php require __DIR__ . '/../config.php'; require_login();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $id = (int)($_POST['id'] ?? 0);
    $qty = max(1, (int)($_POST['qty'] ?? 1));
    $stmt = $pdo->prepare("SELECT id FROM menu_items WHERE id = ? AND is_available = 1");
    $stmt->execute([$id]);
    if ($stmt->fetch()) {
        $_SESSION['cart'] = $_SESSION['cart'] ?? [];
        $_SESSION['cart'][$id] = ['qty' => ($_SESSION['cart'][$id]['qty'] ?? 0) + $qty];
    }
    header("Location: /restaurant_dbms/cart.php");
    exit;
}
if (($_GET['remove'] ?? '') && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    unset($_SESSION['cart'][$id]);
    header("Location: /restaurant_dbms/cart.php");
    exit;
}
header("Location: /restaurant_dbms/index.php");
