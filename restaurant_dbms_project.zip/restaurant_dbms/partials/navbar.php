<?php require_once __DIR__ . '/../config.php'; ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand fw-bold" href="/restaurant_dbms/index.php">RestoDBMS</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample07" aria-controls="navbarsExample07" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExample07">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="/restaurant_dbms/index.php">Menu</a></li>
        <?php if (is_logged_in()): ?>
          <li class="nav-item"><a class="nav-link" href="/restaurant_dbms/cart.php">Cart</a></li>
          <li class="nav-item"><a class="nav-link" href="/restaurant_dbms/customer/my_orders.php">My Orders</a></li>
        <?php endif; ?>
        <?php if (is_logged_in() && current_user()['role'] === 'admin'): ?>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Admin</a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="/restaurant_dbms/admin/dashboard.php">Dashboard</a></li>
              <li><a class="dropdown-item" href="/restaurant_dbms/admin/manage_menu.php">Manage Menu</a></li>
              <li><a class="dropdown-item" href="/restaurant_dbms/admin/manage_orders.php">Manage Orders</a></li>
              <li><a class="dropdown-item" href="/restaurant_dbms/admin/manage_categories.php">Manage Categories</a></li>
            </ul>
          </li>
        <?php endif; ?>
      </ul>
      <ul class="navbar-nav">
        <?php if (!is_logged_in()): ?>
          <li class="nav-item"><a class="nav-link" href="/restaurant_dbms/register.php">Register</a></li>
          <li class="nav-item"><a class="nav-link" href="/restaurant_dbms/login.php">Login</a></li>
        <?php else: ?>
          <li class="nav-item"><span class="navbar-text me-2">Hi, <?= htmlspecialchars(current_user()['name']) ?></span></li>
          <li class="nav-item"><a class="btn btn-sm btn-outline-light" href="/restaurant_dbms/logout.php">Logout</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
