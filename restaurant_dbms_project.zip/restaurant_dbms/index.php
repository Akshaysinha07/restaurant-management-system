<?php require __DIR__ . '/config.php'; ?>
<?php require __DIR__ . '/partials/header.php'; ?>
<?php require __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h2 class="mb-0">Menu</h2>
    <?php if (!is_logged_in()): ?>
      <a href="/restaurant_dbms/login.php" class="btn btn-primary">Login to Order</a>
    <?php else: ?>
      <a href="/restaurant_dbms/cart.php" class="btn btn-outline-light">View Cart</a>
    <?php endif; ?>
  </div>

  <form class="row g-3 mb-4" method="get">
    <div class="col-md-4">
      <select class="form-select" name="cat">
        <option value="">All Categories</option>
        <?php
          $cats = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
          $selected = $_GET['cat'] ?? '';
          foreach ($cats as $c) {
              $sel = ($selected == $c['id']) ? 'selected' : '';
              echo "<option value='{$c['id']}' $sel>" . htmlspecialchars($c['name']) . "</option>";
          }
        ?>
      </select>
    </div>
    <div class="col-md-4">
      <input class="form-control" type="search" name="q" placeholder="Search dishes..." value="<?= htmlspecialchars($_GET['q'] ?? '') ?>">
    </div>
    <div class="col-md-4">
      <button class="btn btn-primary" type="submit">Filter</button>
      <a class="btn btn-secondary" href="/restaurant_dbms/index.php">Reset</a>
    </div>
  </form>

  <div class="row g-3">
    <?php
      $where = [];
      $params = [];
      if (!empty($_GET['cat'])) { $where[] = "category_id = ?"; $params[] = $_GET['cat']; }
      if (!empty($_GET['q'])) { $where[] = "name LIKE ?"; $params[] = '%' . $_GET['q'] . '%'; }
      $sql = "SELECT m.*, c.name AS catname FROM menu_items m LEFT JOIN categories c ON m.category_id = c.id";
      if ($where) $sql .= " WHERE " . implode(" AND ", $where);
      $sql .= " ORDER BY m.id DESC";
      $stmt = $pdo->prepare($sql);
      $stmt->execute($params);
      $items = $stmt->fetchAll();
      if (!$items) {
        echo "<p>No items found.</p>";
      }
      foreach ($items as $it):
    ?>
      <div class="col-md-3">
        <div class="card h-100">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title"><?= htmlspecialchars($it['name']) ?></h5>
            <p class="text-muted mb-1"><?= htmlspecialchars($it['catname'] ?? 'Uncategorized') ?></p>
            <p class="card-text flex-grow-1"><?= htmlspecialchars($it['description']) ?></p>
            <div class="d-flex justify-content-between align-items-center">
              <span class="fw-bold">₹<?= number_format($it['price'], 2) ?></span>
              <?php if ($it['is_available']): ?>
              <form method="post" action="/restaurant_dbms/actions/add_to_cart.php" class="d-flex align-items-center">
                <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                <input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
                <input type="number" name="qty" min="1" max="10" value="1" class="form-control form-control-sm me-2" style="width:80px;">
                <button class="btn btn-sm btn-primary" type="submit" <?= is_logged_in() ? '' : 'disabled' ?>>Add</button>
              </form>
              <?php else: ?>
                <span class="badge text-bg-secondary">Unavailable</span>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<?php require __DIR__ . '/partials/footer.php'; ?>
