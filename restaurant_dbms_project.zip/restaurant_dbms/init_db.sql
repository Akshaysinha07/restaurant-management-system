-- Create database (run this once in phpMyAdmin or MySQL console)
CREATE DATABASE IF NOT EXISTS restaurant_dbms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE restaurant_dbms;

-- Users
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('customer', 'admin') NOT NULL DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Categories
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE
);

-- Menu items
CREATE TABLE IF NOT EXISTS menu_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    is_available TINYINT(1) NOT NULL DEFAULT 1,
    image_url VARCHAR(255),
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- Orders
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    status ENUM('pending','preparing','ready','completed','cancelled') NOT NULL DEFAULT 'pending',
    total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Order items
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    menu_item_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (menu_item_id) REFERENCES menu_items(id) ON DELETE RESTRICT
);

-- Seed categories
INSERT IGNORE INTO categories (id, name) VALUES
(1, 'Starters'),
(2, 'Main Course'),
(3, 'Beverages'),
(4, 'Desserts');

-- Seed menu
INSERT IGNORE INTO menu_items (id, category_id, name, description, price, is_available, image_url) VALUES
(1, 1, 'Veg Spring Rolls', 'Crispy vegetable spring rolls', 149.00, 1, NULL),
(2, 2, 'Paneer Butter Masala', 'Paneer in rich tomato gravy', 249.00, 1, NULL),
(3, 3, 'Masala Chai', 'Spiced Indian tea', 49.00, 1, NULL),
(4, 4, 'Gulab Jamun', 'Warm syrupy dumplings', 99.00, 1, NULL);

-- Create an initial customer (password to be set via register or seed script)
INSERT IGNORE INTO users (id, name, email, password_hash, role) VALUES
(1, 'First Customer', 'customer@demo.com', '$2y$10$abcdefghijklmnopqrstuv12345678901234567890123456789012', 'customer'); -- placeholder hash
