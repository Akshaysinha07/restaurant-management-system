Restaurant Management System (PHP + MySQL + XAMPP)
==================================================

Features
--------
- User auth (register, login, logout) with password hashing.
- Session-based cart and order placement.
- Admin dashboard: stats, manage categories, manage menu items (CRUD), manage orders (update status), view order detail.
- Basic Bootstrap 5 UI (dark theme).

Quick Start (XAMPP)
-------------------
1) Start Apache and MySQL in XAMPP Control Panel.
2) Open phpMyAdmin -> Import -> choose init_db.sql (inside this folder). This creates database & sample data.
3) Copy the entire folder `restaurant_dbms` into your `htdocs` (usually C:\xampp\htdocs\ on Windows).
4) Visit http://localhost/restaurant_dbms/
5) Create an admin: open http://localhost/restaurant_dbms/seed_admin.php (ONLY ONCE). It will create:
   - email: admin@demo.com
   - password: admin123
   Then DELETE seed_admin.php from the folder for security.
6) Register a normal user from the UI, login, add items to cart, place orders.
7) Login as admin to manage menu/categories/orders.

Notes
-----
- DB credentials live in config.php (default XAMPP: root + empty password).
- CSRF tokens are used for form POSTs; sessions are required.
- For production, use a real web server and configure HTTPS; restrict seed_admin.php and remove it after use.

Folder Structure
----------------
restaurant_dbms/
  admin/
    dashboard.php
    manage_categories.php
    manage_menu.php
    manage_orders.php
    view_order.php
  actions/
    add_to_cart.php
    place_order.php
  customer/
    my_orders.php
  partials/
    header.php
    navbar.php
    footer.php
  config.php
  index.php
  login.php
  logout.php
  register.php
  init_db.sql
  styles.css
  seed_admin.php
  README.txt
