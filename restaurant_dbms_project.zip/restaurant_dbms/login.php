<?php require __DIR__ . '/config.php'; ?>
<?php require __DIR__ . '/partials/header.php'; ?>
<?php require __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4" style="max-width:520px;">
  <h3>Login</h3>
  <?php
    $error = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        verify_csrf();
        $email = trim($_POST['email'] ?? '');
        $pass = $_POST['password'] ?? '';
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if ($user && password_verify($pass, $user['password_hash'])) {
            $_SESSION['user'] = [
                'id' => $user['id'],
                'name' => $user['name'],
                'email' => $user['email'],
                'role' => $user['role']
            ];
            $next = $_GET['next'] ?? '/restaurant_dbms/index.php';
            header("Location: " . $next);
            exit;
        } else {
            $error = 'Invalid credentials';
        }
    }
  ?>
  <?php if (isset($_GET['registered'])): ?><div class="alert alert-success">Registration successful. Please login.</div><?php endif; ?>
  <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" class="form-control" name="email" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Password</label>
      <input type="password" class="form-control" name="password" required>
    </div>
    <button class="btn btn-primary" type="submit">Login</button>
    <a class="btn btn-secondary" href="/restaurant_dbms/register.php">Register</a>
  </form>
  <div class="mt-3">
    <small>Need an admin? Run <code>seed_admin.php</code> once.</small>
  </div>
</div>

<?php require __DIR__ . '/partials/footer.php'; ?>
