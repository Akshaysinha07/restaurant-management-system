<?php
// Run ONCE to create an admin user: navigate to /restaurant_dbms/seed_admin.php
// It will create admin@demo.com with password admin123 (if not exists). Then DELETE this file.
require __DIR__ . '/config.php';

$email = 'admin@demo.com';
$password = 'admin123';
$name = 'Administrator';

$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);
if ($stmt->fetch()) {
    echo "Admin already exists. Nothing to do.";
    exit;
}

$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $pdo->prepare("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'admin')");
$stmt->execute([$name, $email, $hash]);

echo "Admin user created: {$email} / {$password}. Please DELETE seed_admin.php for security.";
