<?php require __DIR__ . '/config.php'; ?>
<?php require __DIR__ . '/partials/header.php'; ?>
<?php require __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4" style="max-width:560px;">
  <h3>Create account</h3>
  <?php
    $error = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        verify_csrf();
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $pass = $_POST['password'] ?? '';
        if (!$name || !$email || !$pass) {
            $error = 'All fields are required.';
        } else {
            try {
                $hash = password_hash($pass, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)");
                $stmt->execute([$name, $email, $hash]);
                header("Location: /restaurant_dbms/login.php?registered=1");
                exit;
            } catch (PDOException $e) {
                $error = 'Email already exists or invalid data.';
            }
        }
    }
  ?>
  <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
    <div class="mb-3">
      <label class="form-label">Name</label>
      <input class="form-control" name="name" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" class="form-control" name="email" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Password</label>
      <input type="password" class="form-control" name="password" required>
    </div>
    <button class="btn btn-primary" type="submit">Register</button>
    <a class="btn btn-secondary" href="/restaurant_dbms/login.php">Login</a>
  </form>
</div>

<?php require __DIR__ . '/partials/footer.php'; ?>
