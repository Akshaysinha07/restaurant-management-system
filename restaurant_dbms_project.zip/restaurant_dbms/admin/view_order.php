<?php require __DIR__ . '/../config.php'; require_admin(); ?>
<?php require __DIR__ . '/../partials/header.php'; ?>
<?php require __DIR__ . '/../partials/navbar.php'; ?>

<div class="container py-4">
  <?php
    $id = (int)($_GET['id'] ?? 0);
    $o = $pdo->prepare("SELECT o.*, u.name AS uname, u.email FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?");
    $o->execute([$id]);
    $order = $o->fetch();
    if (!$order) { echo "<div class='alert alert-danger'>Order not found.</div>"; require __DIR__ . '/../partials/footer.php'; exit; }
    $it = $pdo->prepare("SELECT oi.*, m.name FROM order_items oi JOIN menu_items m ON oi.menu_item_id=m.id WHERE order_id=?");
    $it->execute([$id]);
    $rows = $it->fetchAll();
  ?>
  <h3>Order #<?= (int)$order['id'] ?></h3>
  <p class="text-muted mb-1">Customer: <?= htmlspecialchars($order['uname']) ?> (<?= htmlspecialchars($order['email']) ?>)</p>
  <p class="text-muted">Created: <?= htmlspecialchars($order['created_at']) ?></p>

  <div class="table-responsive">
    <table class="table table-striped">
      <thead><tr><th>Item</th><th>Qty</th><th class="text-end">Price</th><th class="text-end">Subtotal</th></tr></thead>
      <tbody>
        <?php $sum = 0; foreach ($rows as $r): $sub = $r['quantity']*$r['unit_price']; $sum += $sub; ?>
          <tr>
            <td><?= htmlspecialchars($r['name']) ?></td>
            <td><?= (int)$r['quantity'] ?></td>
            <td class="text-end">₹<?= number_format($r['unit_price'],2) ?></td>
            <td class="text-end">₹<?= number_format($sub,2) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr><th colspan="3" class="text-end">Total</th><th class="text-end">₹<?= number_format($sum,2) ?></th></tr>
      </tfoot>
    </table>
  </div>
  <a class="btn btn-secondary" href="/restaurant_dbms/admin/manage_orders.php">Back</a>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
