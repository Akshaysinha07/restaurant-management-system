<?php require __DIR__ . '/../config.php'; require_admin(); ?>
<?php require __DIR__ . '/../partials/header.php'; ?>
<?php require __DIR__ . '/../partials/navbar.php'; ?>

<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Manage Menu</h3>
    <a class="btn btn-primary" href="manage_menu.php?create=1">Add Item</a>
  </div>

  <?php
    if (isset($_GET['create']) || isset($_GET['edit'])) {
        $item = ['id'=>null,'name'=>'','description'=>'','price'=>'','category_id'=>null,'is_available'=>1,'image_url'=>null];
        if (isset($_GET['edit'])) {
            $id = (int)$_GET['edit'];
            $st = $pdo->prepare("SELECT * FROM menu_items WHERE id = ?"); $st->execute([$id]); $item = $st->fetch();
            if (!$item) { echo "<div class='alert alert-danger'>Item not found.</div>"; }
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf();
            $name = trim($_POST['name']); $desc = trim($_POST['description']); $price = (float)$_POST['price'];
            $cat = $_POST['category_id'] ? (int)$_POST['category_id'] : null; $avail = isset($_POST['is_available']) ? 1 : 0;
            $img = trim($_POST['image_url'] ?? '');
            if (isset($_GET['edit'])) {
                $st = $pdo->prepare("UPDATE menu_items SET name=?, description=?, price=?, category_id=?, is_available=?, image_url=? WHERE id=?");
                $st->execute([$name,$desc,$price,$cat,$avail,$img ?: null,(int)$_GET['edit']]);
            } else {
                $st = $pdo->prepare("INSERT INTO menu_items (name, description, price, category_id, is_available, image_url) VALUES (?,?,?,?,?,?)");
                $st->execute([$name,$desc,$price,$cat,$avail,$img ?: null]);
            }
            header("Location: manage_menu.php"); exit;
        }
        $cats = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
  ?>
    <form method="post" class="card p-3">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Name</label>
          <input class="form-control" name="name" value="<?= htmlspecialchars($item['name'] ?? '') ?>" required>
        </div>
        <div class="col-md-3">
          <label class="form-label">Price (₹)</label>
          <input type="number" step="0.01" class="form-control" name="price" value="<?= htmlspecialchars($item['price'] ?? '') ?>" required>
        </div>
        <div class="col-md-3">
          <label class="form-label">Category</label>
          <select class="form-select" name="category_id">
            <option value="">--Select--</option>
            <?php foreach ($cats as $c): $sel = ($item['category_id'] ?? null) == $c['id'] ? 'selected' : ''; ?>
              <option value="<?= (int)$c['id'] ?>" <?= $sel ?>><?= htmlspecialchars($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-12">
          <label class="form-label">Description</label>
          <textarea class="form-control" name="description" rows="3"><?= htmlspecialchars($item['description'] ?? '') ?></textarea>
        </div>
        <div class="col-md-6">
          <label class="form-label">Image URL (optional)</label>
          <input class="form-control" name="image_url" value="<?= htmlspecialchars($item['image_url'] ?? '') ?>">
        </div>
        <div class="col-md-6 d-flex align-items-end">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="is_available" id="avail" <?= ($item['is_available'] ?? 1) ? 'checked' : '' ?>>
            <label class="form-check-label" for="avail">Available</label>
          </div>
        </div>
      </div>
      <div class="mt-3 d-flex gap-2">
        <a class="btn btn-secondary" href="manage_menu.php">Cancel</a>
        <button class="btn btn-primary" type="submit">Save</button>
      </div>
    </form>
  <?php
    } else {
        $items = $pdo->query("SELECT m.*, c.name AS cat FROM menu_items m LEFT JOIN categories c ON m.category_id=c.id ORDER BY m.id DESC")->fetchAll();
  ?>
    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead><tr><th>ID</th><th>Name</th><th>Category</th><th class="text-end">Price</th><th>Avail</th><th></th></tr></thead>
        <tbody>
          <?php foreach ($items as $i): ?>
            <tr>
              <td><?= (int)$i['id'] ?></td>
              <td><?= htmlspecialchars($i['name']) ?></td>
              <td><?= htmlspecialchars($i['cat'] ?? '-') ?></td>
              <td class="text-end">₹<?= number_format($i['price'],2) ?></td>
              <td><?= $i['is_available'] ? 'Yes' : 'No' ?></td>
              <td class="text-end">
                <a class="btn btn-sm btn-outline-light" href="manage_menu.php?edit=<?= (int)$i['id'] ?>">Edit</a>
                <a class="btn btn-sm btn-danger" href="manage_menu.php?delete=<?= (int)$i['id'] ?>" onclick="return confirm('Delete?')">Delete</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php
        if (isset($_GET['delete'])) {
            $id = (int)$_GET['delete'];
            $pdo->prepare("DELETE FROM menu_items WHERE id = ?")->execute([$id]);
            header("Location: manage_menu.php"); exit;
        }
    }
  ?>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
