<?php require __DIR__ . '/../config.php'; require_admin(); ?>
<?php require __DIR__ . '/../partials/header.php'; ?>
<?php require __DIR__ . '/../partials/navbar.php'; ?>

<div class="container py-4">
  <h3>Manage Orders</h3>
  <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        verify_csrf();
        $id = (int)$_POST['id'];
        $status = $_POST['status'] ?? 'pending';
        $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->execute([$status, $id]);
        echo '<div class="alert alert-success">Order updated.</div>';
    }
    $orders = $pdo->query("SELECT o.*, u.name AS uname FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.id DESC")->fetchAll();
  ?>
  <div class="table-responsive">
    <table class="table table-striped align-middle">
      <thead><tr><th>ID</th><th>User</th><th class="text-end">Total</th><th>Status</th><th>Created</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($orders as $o): ?>
          <tr>
            <td>#<?= (int)$o['id'] ?></td>
            <td><?= htmlspecialchars($o['uname']) ?></td>
            <td class="text-end">₹<?= number_format($o['total'],2) ?></td>
            <td>
              <form method="post" class="d-flex align-items-center gap-2">
                <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                <input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
                <select class="form-select form-select-sm" name="status">
                  <?php foreach (['pending','preparing','ready','completed','cancelled'] as $s): ?>
                    <option value="<?= $s ?>" <?= $o['status']===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
                  <?php endforeach; ?>
                </select>
                <button class="btn btn-sm btn-primary">Update</button>
              </form>
            </td>
            <td><?= htmlspecialchars($o['created_at']) ?></td>
            <td><a class="btn btn-sm btn-outline-light" href="view_order.php?id=<?= (int)$o['id'] ?>">View</a></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
