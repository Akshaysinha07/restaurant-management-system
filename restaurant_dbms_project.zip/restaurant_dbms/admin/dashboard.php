<?php require __DIR__ . '/../config.php'; require_admin(); ?>
<?php require __DIR__ . '/../partials/header.php'; ?>
<?php require __DIR__ . '/../partials/navbar.php'; ?>

<div class="container py-4">
  <h3>Admin Dashboard</h3>
  <?php
    $stats = [
      'users' => $pdo->query("SELECT COUNT(*) c FROM users")->fetch()['c'],
      'menu'  => $pdo->query("SELECT COUNT(*) c FROM menu_items")->fetch()['c'],
      'orders'=> $pdo->query("SELECT COUNT(*) c FROM orders")->fetch()['c'],
      'revenue' => $pdo->query("SELECT IFNULL(SUM(total),0) s FROM orders WHERE status IN ('preparing','ready','completed')")->fetch()['s'],
    ];
    $recent = $pdo->query("SELECT id, user_id, total, status, created_at FROM orders ORDER BY id DESC LIMIT 10")->fetchAll();
  ?>
  <div class="row g-3 mb-4">
    <div class="col-md-3"><div class="card p-3"><div class="text-muted">Users</div><div class="fs-3 fw-bold"><?= (int)$stats['users'] ?></div></div></div>
    <div class="col-md-3"><div class="card p-3"><div class="text-muted">Menu Items</div><div class="fs-3 fw-bold"><?= (int)$stats['menu'] ?></div></div></div>
    <div class="col-md-3"><div class="card p-3"><div class="text-muted">Orders</div><div class="fs-3 fw-bold"><?= (int)$stats['orders'] ?></div></div></div>
    <div class="col-md-3"><div class="card p-3"><div class="text-muted">Revenue (₹)</div><div class="fs-3 fw-bold"><?= number_format($stats['revenue'],2) ?></div></div></div>
  </div>

  <div class="card">
    <div class="card-body">
      <h5 class="card-title">Recent Orders</h5>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>ID</th><th>User</th><th>Status</th><th class="text-end">Total</th><th>Created</th></tr></thead>
          <tbody>
            <?php foreach ($recent as $r):
              $u = $pdo->prepare("SELECT name FROM users WHERE id = ?"); $u->execute([$r['user_id']]); $uname = $u->fetch()['name'] ?? 'User #'.$r['user_id'];
            ?>
              <tr>
                <td>#<?= (int)$r['id'] ?></td>
                <td><?= htmlspecialchars($uname) ?></td>
                <td><span class="badge bg-info text-dark text-uppercase"><?= htmlspecialchars($r['status']) ?></span></td>
                <td class="text-end">₹<?= number_format($r['total'],2) ?></td>
                <td><?= htmlspecialchars($r['created_at']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
