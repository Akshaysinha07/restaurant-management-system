<?php require __DIR__ . '/../config.php'; require_admin(); ?>
<?php require __DIR__ . '/../partials/header.php'; ?>
<?php require __DIR__ . '/../partials/navbar.php'; ?>

<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Manage Categories</h3>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#catModal">Add Category</button>
  </div>

  <?php
    $cats = $pdo->query("SELECT * FROM categories ORDER BY id DESC")->fetchAll();
    if (isset($_POST['save'])) {
        verify_csrf();
        $name = trim($_POST['name'] ?? '');
        if ($name) {
            $stmt = $pdo->prepare("INSERT INTO categories (name) VALUES (?)");
            $stmt->execute([$name]);
            header("Location: manage_categories.php"); exit;
        }
    }
    if (isset($_GET['delete'])) {
        $id = (int)$_GET['delete'];
        $pdo->prepare("DELETE FROM categories WHERE id = ?")->execute([$id]);
        header("Location: manage_categories.php"); exit;
    }
  ?>

  <div class="table-responsive">
    <table class="table table-striped">
      <thead><tr><th>ID</th><th>Name</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($cats as $c): ?>
          <tr>
            <td><?= (int)$c['id'] ?></td>
            <td><?= htmlspecialchars($c['name']) ?></td>
            <td class="text-end">
              <a class="btn btn-sm btn-danger" href="?delete=<?= (int)$c['id'] ?>" onclick="return confirm('Delete?')">Delete</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="catModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="post">
      <div class="modal-header"><h5 class="modal-title">Add Category</h5></div>
      <div class="modal-body">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <div class="mb-3">
          <label class="form-label">Name</label>
          <input class="form-control" name="name" required>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal" type="button">Close</button>
        <button class="btn btn-primary" name="save" value="1">Save</button>
      </div>
    </form>
  </div>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
