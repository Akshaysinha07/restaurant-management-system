<?php require __DIR__ . '/../config.php'; require_login(); ?>
<?php require __DIR__ . '/../partials/header.php'; ?>
<?php require __DIR__ . '/../partials/navbar.php'; ?>

<div class="container py-4">
  <h3>My Orders</h3>
  <?php if (isset($_GET['placed'])): ?><div class="alert alert-success">Order placed successfully!</div><?php endif; ?>
  <?php
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC");
    $stmt->execute([current_user()['id']]);
    $orders = $stmt->fetchAll();
    if (!$orders) { echo "<p>No orders yet.</p>"; }
    foreach ($orders as $o):
  ?>
    <div class="card mb-3">
      <div class="card-body">
        <div class="d-flex justify-content-between">
          <div>
            <h5 class="mb-1">Order #<?= (int)$o['id'] ?></h5>
            <small class="text-muted"><?= htmlspecialchars($o['created_at']) ?></small>
          </div>
          <div>
            <span class="badge bg-info text-dark text-uppercase"><?= htmlspecialchars($o['status']) ?></span>
          </div>
        </div>
        <?php
          $it = $pdo->prepare("SELECT oi.*, m.name FROM order_items oi JOIN menu_items m ON oi.menu_item_id = m.id WHERE order_id = ?");
          $it->execute([$o['id']]);
          $rows = $it->fetchAll();
        ?>
        <div class="table-responsive mt-2">
          <table class="table table-sm">
            <thead><tr><th>Item</th><th>Qty</th><th class="text-end">Price</th><th class="text-end">Subtotal</th></tr></thead>
            <tbody>
              <?php $sum=0; foreach ($rows as $r): $sub=$r['quantity']*$r['unit_price']; $sum+=$sub; ?>
                <tr>
                  <td><?= htmlspecialchars($r['name']) ?></td>
                  <td><?= (int)$r['quantity'] ?></td>
                  <td class="text-end">₹<?= number_format($r['unit_price'], 2) ?></td>
                  <td class="text-end">₹<?= number_format($sub, 2) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
            <tfoot>
              <tr><th colspan="3" class="text-end">Total</th><th class="text-end">₹<?= number_format($sum, 2) ?></th></tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
