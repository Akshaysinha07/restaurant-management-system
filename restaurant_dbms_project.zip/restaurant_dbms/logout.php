<?php require __DIR__ . '/config.php'; session_destroy(); header("Location: /restaurant_dbms/index.php"); exit; ?>
