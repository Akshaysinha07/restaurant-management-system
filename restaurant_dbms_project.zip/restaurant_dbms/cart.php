<?php require __DIR__ . '/config.php'; require_login(); ?>
<?php require __DIR__ . '/partials/header.php'; ?>
<?php require __DIR__ . '/partials/navbar.php'; ?>

<div class="container py-4">
  <h3>Your Cart</h3>
  <?php
    $cart = $_SESSION['cart'] ?? [];
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        verify_csrf();
        if (isset($_POST['update'])) {
            foreach ($cart as $id => $item) {
                $qty = max(1, (int)($_POST['qty'][$id] ?? $item['qty']));
                $cart[$id]['qty'] = $qty;
            }
            $_SESSION['cart'] = $cart;
            echo '<div class="alert alert-success">Cart updated.</div>';
        }
    }
    if (!$cart) {
        echo "<p>No items in cart.</p>";
    } else {
        $ids = array_keys($cart);
        $in = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare("SELECT * FROM menu_items WHERE id IN ($in)");
        $stmt->execute($ids);
        $items = $stmt->fetchAll();
        $sum = 0;
  ?>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
    <table class="table table-striped align-middle">
      <thead><tr><th>Item</th><th class="text-end">Price</th><th style="width:120px;">Qty</th><th class="text-end">Subtotal</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($items as $it):
          $qty = $cart[$it['id']]['qty'];
          $sub = $qty * $it['price']; $sum += $sub;
      ?>
        <tr>
          <td><?= htmlspecialchars($it['name']) ?></td>
          <td class="text-end">₹<?= number_format($it['price'], 2) ?></td>
          <td><input type="number" class="form-control" name="qty[<?= (int)$it['id'] ?>]" value="<?= (int)$qty ?>" min="1" max="20"></td>
          <td class="text-end">₹<?= number_format($sub, 2) ?></td>
          <td><a class="btn btn-sm btn-danger" href="/restaurant_dbms/actions/add_to_cart.php?remove=1&id=<?= (int)$it['id'] ?>">Remove</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr><th colspan="3" class="text-end">Total</th><th class="text-end">₹<?= number_format($sum, 2) ?></th><th></th></tr>
      </tfoot>
    </table>
    <div class="d-flex gap-2">
      <button class="btn btn-secondary" name="update" value="1">Update Cart</button>
      <a class="btn btn-outline-light" href="/restaurant_dbms/index.php">Continue Shopping</a>
      <a class="btn btn-primary" href="/restaurant_dbms/actions/place_order.php">Place Order</a>
    </div>
  </form>
  <?php } ?>
</div>

<?php require __DIR__ . '/partials/footer.php'; ?>
